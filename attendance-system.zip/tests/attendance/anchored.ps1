$ErrorActionPreference = 'Stop'

$baseUrl = if ($env:BASE_URL) { $env:BASE_URL } else { 'http://localhost:3000' }
$date = if ($env:ATTENDANCE_DATE) { $env:ATTENDANCE_DATE } else { '2026-01-07' }
$goldenPath = Join-Path $PSScriptRoot '..\golden\attendance_anchored.json'

function Normalize-Object {
  param([Parameter(ValueFromPipeline)]$obj)
  if ($null -eq $obj) { return $null }
  if ($obj -is [string]) { return $obj }
  if ($obj -is [System.Collections.IEnumerable] -and -not ($obj -is [string])) {
    $list = @()
    foreach ($item in $obj) { $list += (Normalize-Object $item) }
    return ,$list
  }
  if ($obj.PSObject -and $obj.PSObject.Properties.Count -gt 0) {
    $ordered = [ordered]@{}
    foreach ($name in ($obj.PSObject.Properties.Name | Sort-Object)) {
      $ordered[$name] = Normalize-Object $obj.$name
    }
    return $ordered
  }
  return $obj
}

try {
  $resetBody = @{
    company_id = 'DEFAULT'
    company_timezone = 'Africa/Tunis'
    night_shift_enabled = $true
    day_start_time = '04:00'
    person_id = 'p1'
    date = $date
    events = @(
      @{ event_time_utc = '2026-01-07T06:00:00.000Z'; direction = 'IN'; device_uid = '' },
      @{ event_time_utc = '2026-01-07T16:00:00.000Z'; direction = 'OUT'; device_uid = '' }
    )
  }
  Invoke-RestMethod "$baseUrl/api/ops/test/reset" `
    -Method Post `
    -ContentType 'application/json' `
    -Body ($resetBody | ConvertTo-Json -Depth 5) | Out-Null

  Invoke-RestMethod "$baseUrl/api/attendance?date=$date" | Out-Null
  $res = Invoke-RestMethod "$baseUrl/api/attendance?date=$date"
  $expectedRaw = Get-Content -Raw $goldenPath
  $expected = $expectedRaw | ConvertFrom-Json

  $normActual = Normalize-Object $res | ConvertTo-Json -Depth 10 -Compress
  $normExpected = Normalize-Object $expected | ConvertTo-Json -Depth 10 -Compress

  if ($normActual -ne $normExpected) {
    Write-Host "FAIL: attendance anchored mismatch"
    exit 1
  }
  Write-Host "PASS: attendance anchored"
  exit 0
} catch {
  Write-Host "FAIL: attendance anchored"
  exit 1
}
