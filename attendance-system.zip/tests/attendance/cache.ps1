$ErrorActionPreference = 'Stop'

$baseUrl = if ($env:BASE_URL) { $env:BASE_URL } else { 'http://localhost:3000' }
$date = if ($env:ATTENDANCE_DATE) { $env:ATTENDANCE_DATE } else { '2026-01-08' }

try {
  $first = Invoke-RestMethod "$baseUrl/api/attendance?date=$date"
  if (-not $first -or $first.Count -eq 0 -or $first[0].source -ne 'engine') {
    Write-Host "FAIL: cache first"
    exit 1
  }

  $second = Invoke-RestMethod "$baseUrl/api/attendance?date=$date"
  if (-not $second -or $second.Count -eq 0 -or $second[0].source -ne 'db') {
    Write-Host "FAIL: cache second"
    exit 1
  }

  Write-Host "PASS: cache"
  exit 0
} catch {
  Write-Host "FAIL: cache"
  exit 1
}
