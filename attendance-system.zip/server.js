require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const { getEnv } = require('./config/env');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

const env = getEnv();

// API routes
app.use('/api/system', require('./api/system.routes'));
app.use('/api/employees', require('./api/employees.routes'));
app.use('/api/rule-sets', require('./api/ruleSets.routes'));
app.use('/api/attendance', require('./api/attendance.routes'));
app.use('/api/simulation', require('./api/simulation.routes'));
app.use('/api/device-events', require('./api/deviceEvents.routes'));
app.use('/api/ops', require('./api/ops.routes'));
app.use('/api/ops/test', require('./api/opsTest.routes'));

// ✅ SERVE UI (THIS WAS MISSING)
app.use('/ui', express.static(path.join(__dirname, 'ui')));

// Optional root message
app.get('/', (req, res) => {
  res.send('Attendance system backend is running');
});

app.listen(env.port, () => {
  console.log(`Server running on http://localhost:${env.port}`);
});
