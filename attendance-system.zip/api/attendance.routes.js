const express = require('express');
const router = express.Router();

const engine = require('../engine/AttendanceEngine');
const employees = require('../data/mockEmployees');
const ruleSets = require('../data/mockRuleSets');
const db = require('../db');
const { isWorkingDay } = require('../services/workingDays');
const { isOnLeave } = require('../services/leaves');
const { deriveWorkDate } = require('../services/dayBoundary');
const { getUtcWindowForWorkDate } = require('../services/dayBoundaryWindow');
const { getCompanyConfig } = require('../services/companyConfigProvider');
const {
  buildComputationSignature,
  isSignatureCompatible
} = require('../services/cacheSignature');
const {
  ENGINE_VERSION,
  ENGINE_CONTRACT,
  ATTENDANCE_OUTPUT_CONTRACT,
  SYSTEM_VERSION
} = require('../contracts/systemContracts');

const ENABLE_DAY_BOUNDARY_DEBUG = process.env.ENABLE_DAY_BOUNDARY_DEBUG === 'true';
const USE_DERIVED_WORK_DATE = process.env.USE_DERIVED_WORK_DATE === 'true';

function withDayBoundaryDebug(record, date, config, windowMeta, cacheMeta) {
  if (!ENABLE_DAY_BOUNDARY_DEBUG) {
    return record;
  }

  const sourceTime =
    record.first_in ||
    record.last_out ||
    `${date}T00:00:00.000Z`;

  const derived = deriveWorkDate({
    event_time_utc: sourceTime,
    company_timezone: config.company_timezone,
    night_shift_enabled: config.night_shift_enabled,
    day_start_time: config.day_start_time
  });

  return {
    ...record,
    company_timezone: config.company_timezone,
    night_shift_enabled: config.night_shift_enabled,
    day_start_time: config.day_start_time,
    config_source: config.config_source,
    derived_work_date: derived.work_date,
    day_boundary_mode: derived.mode,
    window_start_utc: windowMeta.window_start_utc,
    window_end_utc: windowMeta.window_end_utc,
    use_derived_work_date: windowMeta.use_derived_work_date,
    cache_valid: cacheMeta.cache_valid,
    cache_reason: cacheMeta.cache_reason
  };
}

router.get('/', async (req, res) => {
  try {
    const date = req.query.date;
    const employee = employees[0];
    const personId = employee.person_id;
    const companyId = employee.company_id || 'DEFAULT';
    const companyConfig = await getCompanyConfig(db, companyId);
    const signature = buildComputationSignature(companyConfig, {
      use_derived_work_date: USE_DERIVED_WORK_DATE
    });

    let windowStartUtc = new Date(`${date}T00:00:00.000Z`).toISOString();
    let windowEndUtc = new Date(`${date}T00:00:00.000Z`);
    windowEndUtc.setUTCDate(windowEndUtc.getUTCDate() + 1);
    windowEndUtc = windowEndUtc.toISOString();
    let windowMode = 'utc';

    if (USE_DERIVED_WORK_DATE) {
      const window = getUtcWindowForWorkDate({
        work_date: date,
        config: companyConfig
      });
      windowStartUtc = window.windowStartUtcIso;
      windowEndUtc = window.windowEndUtcIso;
      windowMode = window.mode;
    }

    const windowMeta = {
      window_start_utc: windowStartUtc,
      window_end_utc: windowEndUtc,
      use_derived_work_date: USE_DERIVED_WORK_DATE,
      mode: windowMode
    };
    let cacheMeta = {
      cache_valid: false,
      cache_reason: 'missing_signature'
    };

    if (!(await isWorkingDay(db, companyId, date))) {
      return res.json([{
        system_version: SYSTEM_VERSION,
        contract: ATTENDANCE_OUTPUT_CONTRACT,
        engine_contract: ENGINE_CONTRACT,
        engine_version: ENGINE_VERSION,
        employee: employee.employee_code,
        status: 'NON_WORKING_DAY',
        first_in: null,
        last_out: null,
        worked_minutes: 0,
        late_minutes: 0,
        break_minutes: 0,
        net_worked_minutes: 0,
        explanation: ['Non-working day (company policy)'],
        source: 'policy'
      }].map(record => withDayBoundaryDebug(record, date, companyConfig, windowMeta, cacheMeta)));
    }

    if (await isOnLeave(db, personId, date)) {
      return res.json([{
        system_version: SYSTEM_VERSION,
        contract: ATTENDANCE_OUTPUT_CONTRACT,
        engine_contract: ENGINE_CONTRACT,
        engine_version: ENGINE_VERSION,
        employee: employee.employee_code,
        status: 'ON_LEAVE',
        first_in: null,
        last_out: null,
        worked_minutes: 0,
        late_minutes: 0,
        break_minutes: 0,
        net_worked_minutes: 0,
        explanation: ['Employee on leave'],
        source: 'policy'
      }].map(record => withDayBoundaryDebug(record, date, companyConfig, windowMeta, cacheMeta)));
    }

    // 1: Try DB cache
    const cached = await db.query(`
      SELECT
        status,
        first_in_utc AS first_in,
        last_out_utc AS last_out,
        worked_minutes,
        late_minutes,
        explanation
      FROM attendance_days
      WHERE person_id = $1 AND work_date = $2
    `, [personId, date]);

    if (cached.rows.length > 0) {
      const cachedRow = cached.rows[0];
      let parsedExplanation = null;
      if (typeof cachedRow.explanation === 'string') {
        try {
          parsedExplanation = JSON.parse(cachedRow.explanation);
        } catch (err) {
          parsedExplanation = null;
        }
      } else if (cachedRow.explanation && typeof cachedRow.explanation === 'object') {
        parsedExplanation = cachedRow.explanation;
      }

      const storedSignature = parsedExplanation
        ? parsedExplanation.computation_context
        : null;
      const compatible = isSignatureCompatible(storedSignature, signature);
      if (!compatible) {
        cacheMeta = {
          cache_valid: false,
          cache_reason: storedSignature ? 'signature_mismatch' : 'missing_signature'
        };
      } else {
        cacheMeta = {
          cache_valid: true,
          cache_reason: 'signature_match'
        };
        const explanationOut = parsedExplanation && Array.isArray(parsedExplanation.explanation)
          ? parsedExplanation.explanation
          : cachedRow.explanation;
        return res.json([{
          system_version: SYSTEM_VERSION,
          contract: ATTENDANCE_OUTPUT_CONTRACT,
          engine_contract: ENGINE_CONTRACT,
          engine_version: ENGINE_VERSION,
          employee: employee.employee_code,
          ...cachedRow,
          explanation: explanationOut,
          source: 'db'
        }].map(record => withDayBoundaryDebug(record, date, companyConfig, windowMeta, cacheMeta)));
      }
    }

    // 2: Load facts from device_events
    const eventsRes = await db.query(`
      SELECT person_id, event_time_utc, direction
      FROM device_events
      WHERE person_id = $1
        AND event_time_utc >= $2
        AND event_time_utc < $3
      ORDER BY event_time_utc
    `, [personId, windowStartUtc, windowEndUtc]);

    const dayEvents = eventsRes.rows.map(e => ({
      person_id: e.person_id,
      event_time: e.event_time_utc,
      direction: e.direction
    }));

    // 3: Compute with engine (IMPORTANT: before any use of result)
    const result = engine.computeDay({
      person: employee,
      date,
      events: dayEvents,
      ruleSet: ruleSets[employee.rule_set_id]
    });

    // 4: Save result to DB
    const explanationPayload = {
      explanation: result.explanation,
      computation_context: signature
    };
    await db.query(`
      INSERT INTO attendance_days
        (person_id, work_date, status, first_in_utc, last_out_utc,
         worked_minutes, late_minutes, explanation)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (person_id, work_date)
      DO UPDATE SET
        status = EXCLUDED.status,
        first_in_utc = EXCLUDED.first_in_utc,
        last_out_utc = EXCLUDED.last_out_utc,
        worked_minutes = EXCLUDED.worked_minutes,
        late_minutes = EXCLUDED.late_minutes,
        explanation = EXCLUDED.explanation,
        computed_at = now()
    `, [
      personId,
      date,
      result.status,
      result.first_in,
      result.last_out,
      result.worked_minutes,
      result.late_minutes,
      JSON.stringify(explanationPayload)
    ]);

    // 5: Response
    res.json([{
      system_version: SYSTEM_VERSION,
      contract: ATTENDANCE_OUTPUT_CONTRACT,
      engine_contract: ENGINE_CONTRACT,
      engine_version: ENGINE_VERSION,
      employee: employee.employee_code,
      ...result,
      source: 'engine'
    }].map(record => withDayBoundaryDebug(record, date, companyConfig, windowMeta, cacheMeta)));

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'attendance computation failed' });
  }
});

module.exports = router;
